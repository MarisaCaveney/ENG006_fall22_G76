Roll_Dice 5 is the online version of the game

FINAL GAME OFFLINE is the offline version

evaluations is a collection of peer evaluations

youTubeLink is the link to the youtube video demonstrating the project
https://www.youtube.com/watch?v=uIhba3FbDEs